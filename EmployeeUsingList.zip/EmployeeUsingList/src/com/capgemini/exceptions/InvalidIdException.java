package com.capgemini.exceptions;

public class InvalidIdException extends Exception {

}
