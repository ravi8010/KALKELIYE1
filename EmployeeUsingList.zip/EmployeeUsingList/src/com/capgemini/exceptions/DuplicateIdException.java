package com.capgemini.exceptions;

public class DuplicateIdException extends Exception{

}
