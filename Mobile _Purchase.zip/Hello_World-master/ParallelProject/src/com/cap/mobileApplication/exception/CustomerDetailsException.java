package com.cap.mobileApplication.exception;

public class CustomerDetailsException extends Exception
{

	public CustomerDetailsException(String string)
	{
		System.out.println(string);
	}

	private static final long serialVersionUID = 1L;
	

}
