package com.capgemini.salesmanagement.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.util.HashMap;

import org.junit.Test;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exception.InvalidProductCatagoryAndDescription;
import com.capgemini.salesmanagement.exception.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exception.InvalidProductCodeException;
import com.capgemini.salesmanagement.exception.InvalidProductPriceException;
import com.capgemini.salesmanagement.exception.InvalidProductQuantityException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class JUnitTestingForBillingSoftwareApplication {

	ISaleService saleService = new SaleService(new SaleDAO());
	
	@Test
	public void whenValidInformationIsPassedBySaleServiceItShouldStoredInHashMap() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		//Dummy Object
		Sale sale = new Sale();
		sale.setCategory("Electronics");
		sale.setDescription("Smart Phone");
		sale.setPrice(3000);
		sale.setProdCode(1001);
		sale.setProductName("iphone");
		sale.setQuantity(2);
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		//Original Saved value
		HashMap<Integer, Sale> hashMapObj2 = saleService.insertSalesDetails(sale);
		Sale saleobj =  hashMapObj2.get(sale.getSaleId());
		
		assertEquals(sale, saleobj);
	}

	@Test(expected = InvalidProductCodeException.class)
	public void whenInvalidProductCodeIsPassedItShouldThrowException() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		Sale sale = new Sale();
		sale.setCategory("Electronics");
		sale.setDescription("Smart Phone");
		sale.setPrice(3000);
		sale.setProdCode(100);	//Wrong product Code
		sale.setProductName("iphone");
		sale.setQuantity(2);
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		saleService.insertSalesDetails(sale);
	}
	
	@Test(expected = InvalidProductQuantityException.class)
	public void whenInvalidProductQuantityIsPassedItShouldThrowException() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		Sale sale = new Sale();
		sale.setCategory("Electronics");
		sale.setDescription("Smart Phone");
		sale.setPrice(3000);
		sale.setProdCode(1001);
		sale.setProductName("iphone");
		sale.setQuantity(6);	//Invalid Quantity
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		saleService.insertSalesDetails(sale);
	}
	
	@Test(expected = InvalidProductCatagoryAndDescription.class)
	public void whenInvalidProductCategoryIsPassedItShouldThrowException() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		Sale sale = new Sale();
		sale.setCategory("LLL");	//No such Category Exist
		sale.setDescription("Smart Phone");	
		sale.setPrice(3000);
		sale.setProdCode(1001);
		sale.setProductName("iphone");
		sale.setQuantity(4);	
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		saleService.insertSalesDetails(sale);
	}
	
	@Test(expected = InvalidProductCatagoryAndDescription.class)
	public void whenInvalidProductDescriptionIsPassedItShouldThrowException() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		Sale sale = new Sale();
		sale.setCategory("Electronics");
		sale.setDescription("OKOK");	//No such Type of Description Exist
		sale.setPrice(3000);
		sale.setProdCode(1001);
		sale.setProductName("iPhone");	
		sale.setQuantity(4);	
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		saleService.insertSalesDetails(sale);
	}
	
	@Test(expected = InvalidProductPriceException.class)
	public void whenInvalidProductPriceIsPassedItShouldThrowException() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		Sale sale = new Sale();
		sale.setCategory("Electronics");
		sale.setDescription("Smart Phone");	
		sale.setPrice(199);		//Invalid Price is Passed
		sale.setProdCode(1001);
		sale.setProductName("iPhone");	
		sale.setQuantity(4);	
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		saleService.insertSalesDetails(sale);
	}
	
	@Test
	public void whenValidInformationIsPassedItWillStoreAndAndReturnHashMap() throws InvalidProductCodeException, InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException {
		Sale sale = new Sale();
		sale.setCategory("Electronics");
		sale.setDescription("Smart Phone");	
		sale.setPrice(50000);
		sale.setProdCode(1001);
		sale.setProductName("iPhone");	
		sale.setQuantity(4);	
		sale.setSaleDate(LocalDate.now());
		sale.setSaleId(1);
		
		if(saleService.insertSalesDetails(sale).size() == 0) {
			fail("Data Is not inserted");
		}
		else {
			//Data is Inserted in hash MAP
		}
	}
	
}
