package com.capgemini.salesmanagement.ui;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exception.InvalidProductCatagoryAndDescription;
import com.capgemini.salesmanagement.exception.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exception.InvalidProductCodeException;
import com.capgemini.salesmanagement.exception.InvalidProductDescriptionException;
import com.capgemini.salesmanagement.exception.InvalidProductPriceException;
import com.capgemini.salesmanagement.exception.InvalidProductQuantityException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	
	private static ISaleService saleService = new SaleService(new SaleDAO());
	
	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		while(true) {
			
			System.out.println("Enter Your Choice");
			System.out.println("1: Create Bill \n"
					+ "2: Exit");
			
			int choice = scanner.nextInt();
			
			switch(choice) {
			
			case 1: insertSalesDetails();
			break;
			
			case 2: System.exit(0);
			
			default: System.out.println("Sorry you have Entered Wrong Choice");
			}
		}

	}
	private static void insertSalesDetails(){
		//Insert Name
		System.out.println("Enter the Product Code");
		int prodCode = scanner.nextInt();
		
		//Insert Product Quantity
		System.out.println("Enter the Quantity");
		int quantity = scanner.nextInt();
		scanner.nextLine();
		
		//Insert Product Category
		System.out.println("Enter the Product Category");
		String category = scanner.nextLine();
		
		//Insert Product Name
		System.out.println("Enter the Product Name");
		String productName = scanner.nextLine();
		
		//Insert Product description
		System.out.println("Enter the description");
		String description = scanner.nextLine();
		
		//Insert Product price
		System.out.println("Enter the Product price");
		float productPrice = scanner.nextFloat();
		
		//Setting Up the Sale Object
		Sale product = new Sale();
		product.setCategory(category);
		product.setLineTotal(productPrice*quantity);
		product.setProdCode(prodCode);
		product.setProductName(productName);
		product.setQuantity(quantity);
		product.setDescription(description);
		product.setPrice(productPrice);
		
		try {
			//Sending Object to the SaleService class
			HashMap<Integer, Sale> sales = saleService.insertSalesDetails(product);
			
			for(Entry<Integer, Sale> entry: sales.entrySet()) {
				Sale value = entry.getValue();
				System.out.println(  "Product Code: " +value.getProdCode() +'\n'
									+"Quantity:     " +value.getQuantity() +'\n'
									+"Category:     " +value.getCategory() +'\n'
									+"Name:         " +value.getProductName() +'\n'
									+"Description:  " +value.getDescription() +'\n'
									+"Price:        " +value.getPrice() +'\n'
									+"Line Total:   "+value.getLineTotal());
			}
			
			
		} catch (InvalidProductCodeException e) {
			System.err.println("Product Code is Invalid");
		} catch (InvalidProductQuantityException e) {
			System.err.println("Product quantity is not correct, it must be greater then Zero and less then five");
		}catch(InvalidProductCategoryException e) {
			System.err.println("product Category is not match");
		}catch(InvalidProductDescriptionException e) {
			System.err.println("Product Description is not match");
		}catch (InvalidProductCatagoryAndDescription e) {
			System.err.println("Product Category and Product Description mismatch");
		} catch (InvalidProductPriceException e) {
			System.err.println("Product Price must be more than RS200");
		}
		
	}

}
