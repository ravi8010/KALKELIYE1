package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {

	/* (non-Javadoc)
	 * @see com.capgemini.salesmanagement.dao.ISaleDAO#insertSaleDetails(com.capgemini.salesmanagement.bean.Sale)
	 */
	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale){
		
		// Fetching the HashMap for CollectionUtil Class file
		HashMap<Integer, Sale> sales = CollectionUtil.getCollection();
		
		//Saving the sales details
		sales.put(sale.getSaleId(), sale);
		
		return sales;
		
	}
}
