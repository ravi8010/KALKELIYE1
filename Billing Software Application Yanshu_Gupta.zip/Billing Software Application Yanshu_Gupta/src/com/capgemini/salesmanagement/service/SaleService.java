package com.capgemini.salesmanagement.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.regex.Pattern;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.exception.InvalidProductCatagoryAndDescription;
import com.capgemini.salesmanagement.exception.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exception.InvalidProductCodeException;
import com.capgemini.salesmanagement.exception.InvalidProductDescriptionException;
import com.capgemini.salesmanagement.exception.InvalidProductPriceException;
import com.capgemini.salesmanagement.exception.InvalidProductQuantityException;

public class SaleService implements ISaleService {

	private ISaleDAO saleDAO;
	
	public SaleService(ISaleDAO saleDAO){
		this.saleDAO = saleDAO;
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.salesmanagement.service.ISaleService#insertSalesDetails(com.capgemini.salesmanagement.bean.Sale)
	 */
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale product) throws InvalidProductCodeException, 
										InvalidProductQuantityException, InvalidProductCatagoryAndDescription,
										InvalidProductPriceException{
		
		if(!(validateProductCode(product.getProdCode()))) {
			// When Product Code Is Invalid
			
			throw new InvalidProductCodeException();
		}
		if(!(validateQuantity(product.getQuantity()))) {
			// When Product Quantity Is less then Zero or more then Five
			throw new InvalidProductQuantityException();
		}
		if(!(validateProductCat(product.getCategory()))) {
			//When product category miss-match
			throw new InvalidProductCategoryException();
		}
		if(!(validateProductDescription(product.getDescription()))) {
			//when product Description is miss-match
			throw new InvalidProductDescriptionException();
		}
		if(!(validateProductPrice(product.getPrice()))) {
			//when product price is less then two hundred
			throw new InvalidProductPriceException();
		}
		if(!(validateProductCatAndDescription(product.getCategory(), product.getDescription()))) {
			// when category is not match according to product Description
			throw new InvalidProductCatagoryAndDescription();		
		}
		int saleId = (int)(100000*(Math.random()));
		product.setSaleId(saleId);
		product.setSaleDate(LocalDate.now());
		
		//Return HashMap when Sale Object is Successfully Validated and saved
		return saleDAO.insertSaleDetails(product);
		
	}
	
	private boolean validateProductCatAndDescription(String category, String productDescription) {
		if(category.equals("Electronics")) {
			if(productDescription.equals("Smart Phone") || productDescription.equals("Video Game")) {
				return true;
			}
			else return false;
		}
		if(category.equals("Toys")) {
			if(productDescription.equals("Soft Toy") || productDescription.equals("Telescope") || productDescription.equals("Barbee Doll")) {
				return true;
			}
			else return false;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.salesmanagement.service.ISaleService#validateProductCode(int)
	 */
	@Override
	public boolean validateProductCode(int productId) {
		return Pattern.matches("[1][0]{2}[1-4]", String.valueOf(productId));
	}
	
	boolean validateQuantity(int qty) {
		if(qty > 0 && qty < 5)	return true;
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.salesmanagement.service.ISaleService#validateProductCat(java.lang.String)
	 */
	@Override
	public boolean validateProductCat(String productCat) {
		if(productCat.equals("Electronics") || productCat.equals("Toys"))	return true;
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.salesmanagement.service.ISaleService#validateProductDescription(java.lang.String)
	 */
	@Override
	public boolean validateProductDescription(String productDescription) {
		if(productDescription.equals("Smart Phone") || productDescription.equals("Video Game")
				|| productDescription.equals("Soft Toy") || productDescription.equals("Telescope")
				|| productDescription.equals("Barbee Doll")) {
			return true;
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.salesmanagement.service.ISaleService#validateProductPrice(float)
	 */
	@Override
	public boolean validateProductPrice(float price) {
		if(price > 200)	return true;
		else return false;
	}
}
