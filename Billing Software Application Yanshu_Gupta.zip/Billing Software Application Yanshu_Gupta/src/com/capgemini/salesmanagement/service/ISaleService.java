package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exception.InvalidProductCatagoryAndDescription;
import com.capgemini.salesmanagement.exception.InvalidProductCodeException;
import com.capgemini.salesmanagement.exception.InvalidProductPriceException;
import com.capgemini.salesmanagement.exception.InvalidProductQuantityException;

public interface ISaleService {

	HashMap<Integer, Sale> insertSalesDetails(Sale product) throws InvalidProductCodeException,
			InvalidProductQuantityException, InvalidProductCatagoryAndDescription, InvalidProductPriceException;

	boolean validateProductCode(int productId);

	boolean validateProductCat(String productCat);

	boolean validateProductDescription(String productDescription);

	boolean validateProductPrice(float price);

}