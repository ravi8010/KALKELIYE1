package com.capgemini.salesmanagement.exception;

public class InvalidProductCategoryException extends InvalidProductCatagoryAndDescription {

}
