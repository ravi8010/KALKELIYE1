package com.capgemini.salesmanagement.exception;

public class InvalidProductDescriptionException extends InvalidProductCatagoryAndDescription {

}
