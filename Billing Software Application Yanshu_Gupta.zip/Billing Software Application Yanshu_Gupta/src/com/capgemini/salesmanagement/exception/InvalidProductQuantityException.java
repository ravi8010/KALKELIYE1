package com.capgemini.salesmanagement.exception;

public class InvalidProductQuantityException extends Exception {

}
