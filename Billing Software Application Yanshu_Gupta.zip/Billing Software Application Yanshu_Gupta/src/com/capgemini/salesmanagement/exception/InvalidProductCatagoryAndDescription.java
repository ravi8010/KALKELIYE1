package com.capgemini.salesmanagement.exception;

public class InvalidProductCatagoryAndDescription extends Exception {

}
