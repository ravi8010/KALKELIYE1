package com.capgemini.salesmanagement.exception;

public class InvalidProductPriceException extends Exception {

}
