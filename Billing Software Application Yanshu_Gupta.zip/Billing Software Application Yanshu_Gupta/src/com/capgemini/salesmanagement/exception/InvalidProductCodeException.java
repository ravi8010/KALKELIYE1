package com.capgemini.salesmanagement.exception;

public class InvalidProductCodeException extends Exception {

}
