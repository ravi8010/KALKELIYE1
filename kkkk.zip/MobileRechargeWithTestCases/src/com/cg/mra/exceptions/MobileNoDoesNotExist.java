package com.cg.mra.exceptions;

public class MobileNoDoesNotExist extends Exception {

}
