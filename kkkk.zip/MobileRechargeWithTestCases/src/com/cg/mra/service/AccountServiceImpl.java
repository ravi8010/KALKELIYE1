package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	AccountDao accountDao= new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) {
		return accountDao.getAccountDetails(mobileNo);
		// TODO Auto-generated method stub
		
	}

	@Override
	public int rechargeAccount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		return accountDao.rechargeAccount(mobileno, rechargeAmount);
	}

}
