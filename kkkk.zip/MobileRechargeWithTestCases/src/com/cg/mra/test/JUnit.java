package com.cg.mra.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class JUnit {
	AccountService accountService = new AccountServiceImpl();

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		System.out.println(
				"your account balance is " + accountService.getAccountDetails("1111111111").getAccountBalance());
	}

	@Test
	public void test1() {
		accountService.rechargeAccount("1111111111", 199D);
		System.out.println(
				"your account balance is " + accountService.getAccountDetails("1111111111").getAccountBalance());
	}

}
