package com.capg.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capg.bean.Sale;
import com.capg.service.ISaleService;
import com.capg.service.SaleService;
import com.capg.util.CollectionUtil;

public class Client {
    static ISaleService is=new SaleService();
    static Scanner sc=new Scanner(System.in);
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	while(true)
	{
		System.out.println("-----Billing Software Application-----");
		System.out.println("1:InsertDetails\n2:DisplayDetails \n3:Exit");
		System.out.println("Enter your Choice");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:insertDetails();
		break;
		case 2:displayDetails();
		break;
		case 3:System.exit(0);
		break;
		
		default:System.out.println("wrong Input");
		}
		
	}

	}

	private static void displayDetails() {
		// TODO Auto-generated method stub
		System.out.println("Enter Sale Id");
		int prodCode=sc.nextInt();
		Sale sale=is.getSalesDetail(prodCode);
		System.out.println("Product Code:"+sale.getProdCode()+"\n"+"Product Category:"+sale.getCategory()+"\n"+"Product Name:"+sale.getProductName()+"\n"+"Line Total "+sale.getQuantity()*sale.getLinetotal());

		
	}

	private static void insertDetails() {
		// TODO Auto-generated method stub
		System.out.println("Enter prodcut code");
		int prodCode=sc.nextInt();
		while(!(is.validateProductCode(prodCode)))
		{
			System.out.println("Enter valid Product Code");
			prodCode=sc.nextInt();
		}
		
		
		
		System.out.println("Enter the Quantity");
		int qty=sc.nextInt();
		if(!(is.validateQuantity(qty)))
		{
			System.out.println("Enter Valid Quantity");
			qty=sc.nextInt();
		}
		sc.nextLine();
		System.out.println("Enter Product Category");
		String prodCat=sc.nextLine();
		while(!(is.validateProductCat(prodCat)))
		{
			System.out.println("Enter Valid Category");
			prodCat=sc.nextLine();
		}
		System.out.println("Enter Product Name");
		String prodName=sc.nextLine();
		while(!(is.validateProductName(prodName)))
		{
			System.out.println("Enter Valid Product Name");
			prodName=sc.nextLine();
		}
		
		System.out.println("Enter Price");
		int price=sc.nextInt();
		while(!(is.validateProductPrice(price)))
		{
			System.out.println("Enter valid Price");
			price=sc.nextInt();
		}
	
		sc.nextLine();
		LocalDate ld=LocalDate.now();
		Sale sale=new Sale();
		sale.setProdCode(prodCode);
		sale.setQuantity(qty);
		sale.setCategory(prodCat);
		sale.setProductName(prodName);
		sale.setLinetotal(price);
		sale.setSaleDate(ld);
		is.insertSalesDetails(sale);
		System.out.println("Generated Id is:"+sale.getSaleId());
		System.out.println("Added Successfully");
		
		
		
	}

}
