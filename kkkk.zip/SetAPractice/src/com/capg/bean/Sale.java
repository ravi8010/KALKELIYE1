package com.capg.bean;

import java.time.LocalDate;

public class Sale {

	private int saleId;
	private int prodCode;
	private String productName;
	private String category;
	private LocalDate saleDate;
	private int quantity;
	private float linetotal;
	public int getSaleId() {
		return saleId;
	}
	public int getProdCode() {
		return prodCode;
	}
	public String getProductName() {
		return productName;
	}
	public String getCategory() {
		return category;
	}
	public LocalDate getSaleDate() {
		return saleDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public float getLinetotal() {
		return linetotal;
	}
	public void setSaleId(int saleId) {
		this.saleId = saleId;
	}
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setSaleDate(LocalDate saleDate) {
		this.saleDate = saleDate;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setLinetotal(float linetotal) {
		this.linetotal = linetotal;
	}
	public Sale() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Sale( int prodCode, String productName, String category, float linetotal) {
		super();

		this.prodCode = prodCode;
		this.productName = productName;
		this.category = category;
		this.linetotal = linetotal;
	}
	@Override
	public String toString() {
		return "Sale [saleId=" + saleId + ", prodCode=" + prodCode + ", productName=" + productName + ", category="
				+ category + ", saleDate=" + saleDate + ", quantity=" + quantity + ", linetotal=" + linetotal + "]";
	}

}

	