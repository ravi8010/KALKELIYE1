package com.capg.service;

import java.util.HashMap;

import com.capg.bean.Sale;

public interface ISaleService {
	public HashMap<Integer,Sale> insertSalesDetails(Sale sale);
	public Sale getSalesDetail(int prodCode);
	public boolean validateProductCode(int prodCode);
	public boolean validateQuantity(int qty);
	public boolean validateProductCat(String prodCat);
	public boolean validateProductName(String prodName);
	public boolean validateProductPrice(float price);
	

}
