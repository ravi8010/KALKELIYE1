package com.capg.service;

import java.util.HashMap;


import com.capg.bean.Sale;
import com.capg.dao.ISaleDAO;
import com.capg.dao.SaleDAO;

public class SaleService implements ISaleService {
    ISaleDAO sd=new SaleDAO();
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		return sd.insertSaleDetails(sale);
		
	}

	@Override
	public boolean validateProductCode(int prodCode) {
		// TODO Auto-generated method stub
		if(prodCode==1001||prodCode==1002||prodCode==1003||prodCode==1004)
		return true;
		return false;
	}

	@Override
	public boolean validateQuantity(int qty) {
		// TODO Auto-generated method stub
		if(qty>0||qty<5)
			return true;
		return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		// TODO Auto-generated method stub
		if(prodCat.equals("Electronics")||prodCat.equals("Toys"))
			return true;
		return false;
	}

	@Override
	public boolean validateProductName(String prodName) {
		// TODO Auto-generated method stub
		if(prodName.equals("TV")||prodName.equals("Smart Phone")||prodName.equals("Video Game")||prodName.equals("Soft Toy")||prodName.equals("TeleScope")||prodName.equals("Barbee Doll"))
		       return true;
		return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		if(price>200)
       {
			return true;
	   }
		return false;
	}

	@Override
	public Sale getSalesDetail(int prodCode) {
		// TODO Auto-generated method stub
		return sd.getSaleDetails(prodCode);
		
	}

}
