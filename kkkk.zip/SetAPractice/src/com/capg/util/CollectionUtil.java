package com.capg.util;

import java.util.HashMap;

import com.capg.bean.Sale;

public class CollectionUtil {
	
	private static HashMap<Integer,Sale> sales=new HashMap<>();
	
	{
		sales.put(1001, new Sale(1001,"IPhone","Electrnics",2000));
		sales.put(1002, new Sale(1002,"LEDTV","Electronics",5000));

		sales.put(1001, new Sale(1003,"Teddy","Toys",2000));
		sales.put(1002, new Sale(1004,"TeleScope","Toys",5000));
	}
  
 public static HashMap<Integer,Sale> getSaleDetails()
 {
	 return sales;
 }
	public static int generateid()
	{
		int id=(int) (Math.random()*10000);
		return id;
	}
	
}
