package com.capg.dao;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capg.bean.Sale;
import com.capg.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {
	HashMap<Integer,Sale> hm=CollectionUtil.getSaleDetails();
  	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		// TODO Auto-generated method stub
  		int key=CollectionUtil.generateid();
  		sale.setSaleId(key);
		hm.put(key, sale);
		return hm;
	}
  	public Sale getSaleDetails(int prodCode) {
  	  	for(Entry<Integer,Sale> entry:hm.entrySet())
  	  	{
  	  		if(prodCode==entry.getKey())
  	  		{
  	  			return entry.getValue();
  	  		}
  	  	}
		return null;
	}
  
}
