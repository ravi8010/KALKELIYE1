package com.capg.dao;

import java.util.HashMap;

import com.capg.bean.Sale;

public interface ISaleDAO {
	public HashMap<Integer,Sale> insertSaleDetails(Sale sale);
	public Sale getSaleDetails(int prodCode);
	

}
