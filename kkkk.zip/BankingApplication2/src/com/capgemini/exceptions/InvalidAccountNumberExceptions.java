package com.capgemini.exceptions;

public class InvalidAccountNumberExceptions extends Exception {

}
