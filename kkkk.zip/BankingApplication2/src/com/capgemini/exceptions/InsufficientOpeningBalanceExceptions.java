package com.capgemini.exceptions;

public class InsufficientOpeningBalanceExceptions extends Exception {

}
