import java.io.BufferedReader;
import java.io.File;
import java.io.Reader;

public class FileIO_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("FileIO_1.java");
		BufferedReader br=new BufferedReader(f);
		String str;
		while(str.readLine()!=null)
		{
			System.out.println(str);
		}
br.close();
f.close();
	}

}
