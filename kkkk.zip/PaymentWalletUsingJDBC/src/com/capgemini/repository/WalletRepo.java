package com.capgemini.repository;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Transaction;

public interface WalletRepo {
	public boolean save(Customer customer);

	public Customer findone(String mobileNumber);
	
	public boolean updateCustomer(Customer customer) throws SQLException;
	
	public boolean saveTransaction(Transaction transaction) throws SQLException;

	public List<Transaction> FindAll(String mobileNubmer) throws SQLException;

}
