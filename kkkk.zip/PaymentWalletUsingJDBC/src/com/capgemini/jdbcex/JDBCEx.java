package com.capgemini.jdbcex;

public class JDBCEx {

}
