
public class NullPointerException1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		try
		{
			int ar1[]=new int[12];
			for(int i=0;i<=11;i++)
			{
				System.out.println(ar1[12]);
			}
			
		try
		{
			String str=null;
			if(str.equals("sbc"))
			{
				System.out.println("same");
			}
			else
			{
				System.out.println("not");
			}
		}catch(NullPointerException er1)
		{
			System.out.println("nullpointr exception");
			System.out.println(er1.getMessage());
			
		}
		}
		catch(Exception er2)
		{
			String[] s= {"1","2","ab"};
			try
			{
				for(int i=0;i<s.length;i++)
				{
		         	int s1=Integer.parseInt(s[i]);
		         	System.out.println(s1);
			}
				}
			
			
			
				catch(Exception er1)
				{
					System.out.println("prsing problem");
					System.out.println(er1.getMessage());
				}
				
			
		
			System.out.println("array exception");
			System.out.println(er2.getMessage());
		}	
		}
		
		
		
	}

