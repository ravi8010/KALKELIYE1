package com.capgemini.exceptions;

public class EmployeeDoesnotExistException extends Exception {

}
