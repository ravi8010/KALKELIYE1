package com.cg.product.exception;

public class ProductException extends Exception {
	public ProductException(String string) {
		System.out.println(string);

}

}
