package Exceptions;

public class ProductCodeDoesNotExist extends Exception {

}
