package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	
	Map<String, Account> accountEntry;
	
	public AccountDaoImpl() {
		
	accountEntry=new HashMap<String, Account>();
	
	accountEntry.put("1111111111", new Account("Prepaid", "Ravi",300));
	accountEntry.put("9837044912", new Account("Prepaid", "Himanshu",100));
	accountEntry.put("8569254784", new Account("Prepaid", "Simran",200));
	accountEntry.put("9865748123", new Account("Prepaid", "Saurabh", 300));
	
	}
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		
		if(accountEntry.containsKey(mobileNo))
			return accountEntry.get(mobileNo);
	
	return null;
	}
	
	

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double balance=0;
		if(accountEntry.containsKey(mobileNo)){
			Account acc= accountEntry.get(mobileNo);
			   balance= rechargeAmount+acc.getAccountBalance();
			acc.setAccountBalance(balance);
		}
		
		// TODO Auto-generated method stub
		
		return balance;
	}

}
