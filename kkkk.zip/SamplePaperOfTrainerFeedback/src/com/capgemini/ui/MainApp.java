package com.capgemini.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatched;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class MainApp {
	static FeedbackService fds = new FeedbackServiceImpl();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		while (true) {
			System.out.println("1:Add Feedback\n 2:Display List\n 3:exit");
			System.out.println("Enter your choice");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				addFeedback();
				break;

			case 2:
				displayTrainerList();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("wrong choice");
			}

		}

	}

	private static void displayTrainerList() {
		// TODO Auto-generated method stub
		System.out.println("Enter Rating ");
		int rating = sc.nextInt();
		// System.out.println(fds.getTrainerList(rating));
		try {
			HashMap<Integer, Trainer> hm = fds.getTrainerList(rating);
			/*
			 * for(Entry<Integer,Trainer> feedback:hm.entrySet()) { Trainer
			 * trainer=feedback.getValue();
			 * System.out.println("Trainer Name: "+trainer.getName()+"  Course Name:"
			 * +trainer.getCourseName()+"  Start date:"+trainer.getStartDate()
			 * +"  End Date :"+trainer.getEndDate()+"  Rating:"+trainer.getRating()); }
			 */
			System.out.println(hm);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// System.out.println("Trainer Name:"+hm.values());

	}

	private static void addFeedback() {
		// TODO Auto-generated method stub
		sc.nextLine();
		System.out.println("Enter Trainer Name");
		String name = sc.nextLine();
		while (!(Pattern.matches("[A-Z,a-z, ]+", name))) {
			System.out.println("Enter valid Name");
			name = sc.nextLine();
		}
		System.out.println("Enter course Name");
		String cname = sc.nextLine();
		System.out.println("Enter Start Date in dd-MM-yyyy ");

		String sdate = sc.nextLine();
        
		while(!validateDate(sdate)) 
		{
			
			System.out.println("Please Enter a valid Date");
			
			sdate = sc.nextLine();
		}
		// LojcalDate sDate= LocalDate.parse(date);
		System.out.println("Enter End Date in dd-MM-yyyy ");

		String edate = sc.nextLine();
		
		while(!validateDate(edate)) 
		{
			System.err.println("Please Enter a valid Date");
			edate = sc.nextLine();
		}

		System.out.println("Enter Rating");
		int rating = sc.nextInt();
		while ((rating <= 0 || rating > 5)) {
			System.out.println("Enter valid Rating");
			rating = sc.nextInt();

		}

		// LocalDate e1Date= LocalDate.parse(edate);

		fds.addFeedback(new Trainer(name, cname, sdate, edate, rating));

	}
	
	static DateTimeFormatter df=DateTimeFormatter.ofPattern("dd-MM-uuuu",Locale.US).withResolverStyle(ResolverStyle.STRICT);
	
	public static boolean validateDate(String date)
	{
		try {
			LocalDate.parse(date,df);
			return true;
		}
		catch(Exception e)
		{
			System.err.println("Date is Invalid");
			return false;
		}
	}

}
