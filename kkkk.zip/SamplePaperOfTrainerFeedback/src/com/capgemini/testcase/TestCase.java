package com.capgemini.testcase;


import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatched;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class TestCase {
	 FeedbackService fds= new FeedbackServiceImpl();

	@Before
	public void setUp() throws Exception {
}

	@Test(expected=com.capgemini.exception.RatingNotMatched.class)
	public void test() throws RatingNotMatched
	{
fds.addFeedback(new Trainer( "name", "courseName","2000-12-10","2001-11-10", 4));
fds.getTrainerList(6);
	}

}
