package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatched;
import com.capgemini.util.DBUtil;

public class FeedbackImpl implements FeedbackDao {
	HashMap<Integer,Trainer> hashmap=DBUtil.getFeedbackList();
	

	@Override

	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		int id=(int) (Math.random()*1000);
		hashmap.put(id, trainer);
	
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws RatingNotMatched {
		
		// TODO Auto-generated method stud
		HashMap<Integer,Trainer> searchedList = new HashMap<>();
		int f=0;
		for(Entry<Integer,Trainer> e:hashmap.entrySet())
		{
			if(rating==e.getValue().getRating())
			{
				f=1;
				searchedList.put(e.getKey(), e.getValue());
			}
			
		}
		if(f==0) throw new RatingNotMatched();
		return searchedList;
	}


}
