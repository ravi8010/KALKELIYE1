package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDao;
import com.capgemini.dao.FeedbackImpl;
import com.capgemini.exception.RatingNotMatched;

public class FeedbackServiceImpl implements FeedbackService {
   FeedbackDao fd=new FeedbackImpl();
	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		fd.addFeedback(trainer);

	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws RatingNotMatched {
		// TODO Auto-generated method stub\
		
		return fd.getTrainerList(rating);
	}

}
