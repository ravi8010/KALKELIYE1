package com.capgemini.exception;

public class RatingNotMatched extends Exception {
	@Override
	public String getMessage()
	{
		return "Trainer of this Rating does not exist";
	}

}
