import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Trainer Name");
		String name=sc.next();
		//while(name==null || name=="" || name==" ")
		while(name==null)
		{
			System.out.println("Enter valid Name");
			name=sc.nextLine();
		}
		
		System.out.println("last line");
	}

}
