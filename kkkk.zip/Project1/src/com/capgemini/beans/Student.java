package com.capgemini.beans;

public class Student {
	private  int rl;
	private  String name;
private	String[] enroll;
	public void setEnroll(String[] enroll) {
	this.enroll = enroll;
}
	

	public int getRl() {
		return rl;
	}
	public void setRl(int rl) {
		this.rl = rl;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


	public String[] getEnroll() {
		return enroll;
	}
	
	

}
