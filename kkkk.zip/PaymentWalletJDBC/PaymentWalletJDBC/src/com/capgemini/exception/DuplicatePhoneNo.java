package com.capgemini.exception;

@SuppressWarnings("serial")
public class DuplicatePhoneNo extends Exception {

}
