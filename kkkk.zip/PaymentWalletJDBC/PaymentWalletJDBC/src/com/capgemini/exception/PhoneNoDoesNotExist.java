package com.capgemini.exception;

@SuppressWarnings("serial")
public class PhoneNoDoesNotExist extends Exception {

}
