
public class Fabonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0,b=1;
		int c;
		for(int i=0;i<10;i++)
		{
			System.out.println(a);
			c=a+b;
			a=b;
			b=c;
			
		}	

	}

}
