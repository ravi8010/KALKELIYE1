import java.util.Scanner;
public class StartS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		
		String[] s= {"Aman","Sam","Sar","Sanam"};
		for(i=0;i<s.length;i++)
		{
			char[] ar1=s[i].toCharArray();
			if(ar1[0]=='s'||ar1[0]=='S')
			{
				System.out.println(s[i]);
			}
				
			
			
				}
		
		
       
       
	}

}
