
public class Base {
	int a=10;
	void print()
	{
		System.out.println(a);
	}
	

}
class Child extends Base
{
	int a=9;
	void print()
	{
		System.out.println(a);
	}
	public static void main(String[] args) {
		Base b=new  Child();
		b.print();
		
	}
	}
