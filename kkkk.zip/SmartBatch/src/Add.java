
public class Add {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=9;
		System.out.println(a+b);

	}

}
