package com.capg.exception;

public class RatingDoesNotExist extends Exception {

}
