package com.capgemini.takehome.exception;

public class ProductNotFound extends Exception {

}
