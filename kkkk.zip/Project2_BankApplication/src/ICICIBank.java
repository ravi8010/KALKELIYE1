import java.util.LinkedList;

public class ICICIBank {
	LinkedList<Account> accounts=new LinkedList<>();
	public String createAccount(int accountNo,int amount)
	{
		Account account=new Account(accountNo, amount);
		accounts.add(account);
		return "Account Created Succesfully";
		
	}
	private Account searchAccount(int accountNo)throws InvalidAccountException
	{
		
		for(Account account:accounts)
		{
			if(account.getAccountNo()==accountNo)
			{
				return account;
			}
				
		}
		throw new InvalidAccountException();
	}
	public  int  withdrawAmount(int accountNo,int amount)throws InSfficientBalanceException,InvalidAccountException
	
	{
           Account account=searchAccount(accountNo);	
           if(account.getAmount()-amount>=0)
        	  
           {
        	   account.setAmount(account.getAmount()-amount);
        	   return account.getAmount();
        	   
           }
           throw new InSfficientBalanceException();
	}
	public int depositAmount(int accountNo,int amount) throws InvalidAccountException
	{
		Account account=searchAccount(accountNo);
	    account.setAmount(account.getAmount()+amount);
	    return account.getAmount();
	    
	}
	public String fundTransfer(int sAccountNo,int rAccountNo,int amount) throws InvalidAccountException, InSfficientBalanceException
	{
		Account as=searchAccount(sAccountNo);
		Account ar=searchAccount(rAccountNo);
		if(as.getAmount()>=amount)
		{
			withdrawAmount(sAccountNo,amount);
			depositAmount(rAccountNo,amount);
			return "Fund Transfered from "+sAccountNo+"to "+rAccountNo+" balance in sender Amount is"+as.getAmount()+"receiver Amount is: "+ar.getAmount();
		
			
		}
		throw new InSfficientBalanceException();
		
	}
	
	

}
