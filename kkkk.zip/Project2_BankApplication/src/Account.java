
public class Account {
	int accountNo,amount;

	public Account(int accountNo, int amount) {
		super();
		this.accountNo = accountNo;
		this.amount = amount;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public int getAmount() {
		return amount;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", amount=" + amount + "]";
	}
	

}
