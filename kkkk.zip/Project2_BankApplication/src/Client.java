
public class Client {

	public static void main(String[] args) throws InvalidAccountException {
		// TODO Auto-generated method stub
		ICICIBank bank=new ICICIBank();
		System.out.println(bank.createAccount(120, 1000));
		System.out.println(bank.createAccount(100, 4000));
		try
		{
			System.out.println("Deposited="+bank.depositAmount(120,2000));
		}
		catch(InvalidAccountException i)
		{
			System.out.println("Invalid account number ");
		}
		try
		{
			System.out.println("Balance="+bank.withdrawAmount(120,1000));
		}
		catch(InvalidAccountException i)
		{
			System.out.println("Invalid account number ");
		}
		catch(InSfficientBalanceException ibe){
			System.out.println("insufficient balance");
		}
		
		
		
			try {
				System.out.println("FundTransfer="+bank.fundTransfer(120,100,1000));
			} catch (InSfficientBalanceException e) {
				// TODO Auto-generated catch block
				System.out.println("insufficient balance");
			}
		}
		
	
	}


