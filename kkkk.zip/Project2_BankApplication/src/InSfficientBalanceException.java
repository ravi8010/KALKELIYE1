
public class InSfficientBalanceException extends Exception {

}
