/*class Mythread extends Thread
{
   
	
	public void run()
    {
		try {
			sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println("child Thread");
         
	
		
	
    }
}


public class ThreadExample {

	public static void main(String[] args) {
		 Mythread mt=new Mythread();

			System.out.println(Thread.currentThread().getName());		
		System.out.println("main Method");
		mt.start();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("second");
	}
}
	*/

class Mythread implements Runnable
{
	public void run()
	{
		System.out.println("childThread");
	}
}
public class ThreadExample {

	public static void main(String[] args) {
		
		Thread t=new Thread(new Mythread());
		t.start();
		/*try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		System.out.printf("mAIN METHOD %d\n", 54);
		
		
     
}

	
	}