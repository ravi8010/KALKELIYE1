package com.cq.mra.exception;

public class MobileDoesNotExist extends Exception {

}
