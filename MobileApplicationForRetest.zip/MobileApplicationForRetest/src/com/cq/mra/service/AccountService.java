package com.cq.mra.service;

import com.cq.mra.beans.Account;
import com.cq.mra.exception.MobileDoesNotExist;

public interface AccountService {
Account getAccountDetails(String mobileNo) throws MobileDoesNotExist;
int rechargeAccount(String mobileNo,double amount);
}
