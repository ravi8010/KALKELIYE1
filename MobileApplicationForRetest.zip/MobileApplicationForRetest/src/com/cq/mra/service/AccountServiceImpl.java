package com.cq.mra.service;

import com.cq.mra.beans.Account;
import com.cq.mra.dao.AccountDAO;
import com.cq.mra.dao.AccountDAOImpl;
import com.cq.mra.exception.MobileDoesNotExist;

public class AccountServiceImpl implements AccountService {
AccountDAO accdao=new AccountDAOImpl();

	@Override
	public Account getAccountDetails(String mobileNo) throws MobileDoesNotExist {
		// TODO Auto-generated method stub
		return accdao.getAccountDetails(mobileNo);
		
	}

	@Override
	public int rechargeAccount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		accdao.rechargeAccount(mobileNo, amount);
		return 1;
		
	}

}
