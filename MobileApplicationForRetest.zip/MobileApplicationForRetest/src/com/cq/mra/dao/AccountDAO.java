package com.cq.mra.dao;

import com.cq.mra.beans.Account;
import com.cq.mra.exception.MobileDoesNotExist;

public interface AccountDAO {
Account getAccountDetails(String mobileNo) throws MobileDoesNotExist;
int rechargeAccount(String mobile,double rechargeAmount);
}
