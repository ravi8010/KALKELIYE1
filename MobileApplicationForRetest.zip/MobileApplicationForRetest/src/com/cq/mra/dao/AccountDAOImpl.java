package com.cq.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cq.mra.beans.Account;
import com.cq.mra.exception.MobileDoesNotExist;

public class AccountDAOImpl implements AccountDAO {
	
	
	Map<String,Account> accountEntry;
	public AccountDAOImpl()
	{
		accountEntry=new HashMap<>();
		accountEntry.put("9012035647", new Account("Prepaid","Simran",200));
		accountEntry.put("9012596878", new Account("Prepaid","Himanshu",300));
		accountEntry.put("9010210131", new Account("Prepaid","Saurabh",400));
		accountEntry.put("7599407259", new Account("Prepaid","Ravi",500));

	}

	@Override
	public Account getAccountDetails(String mobileNo) throws MobileDoesNotExist {
		// TODO Auto-generated method stub
	 int f=0;
		if(accountEntry.containsKey(mobileNo))
		{
			f=1;
			return accountEntry.get(mobileNo);
		
		}
		
		if(f==0) throw new MobileDoesNotExist();
		return null;
		
	
	}

	@Override
	public int rechargeAccount(String mobile, double rechargeAmount) {
		// TODO Auto-generated method stub
		if(accountEntry.containsKey(mobile))
		{
			Account acc=accountEntry.get(mobile);
			acc.setAccountBalance(acc.getAccountBalance()+rechargeAmount);
			return 1;
		}
		return 0;
		
	}

}
