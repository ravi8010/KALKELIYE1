package com.cq.mra.ui;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.cq.mra.beans.Account;
import com.cq.mra.exception.MobileDoesNotExist;
import com.cq.mra.service.AccountService;
import com.cq.mra.service.AccountServiceImpl;

public class MainApp {
	static AccountService acs=new AccountServiceImpl();
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) throws MobileDoesNotExist {
		// TODO Auto-generated method stub
	       while(true)
	       {
	    	   System.out.println("--------Mobile Application-------");
	    	   System.out.println("1:Balance Enquirey\n2:Recharge Account\n3:Exit");
	            System.out.println("Enter Your Choice:");
	            int ch=sc.nextInt();
	            sc.nextLine();
	            switch(ch)
	            {
	            case 1:balanceEnquirey();
	            break;
	            case 2:rechargeAccount();
	            break;
	            case 3:System.exit(0);
	            break;
	            default:System.out.println("Wrong invalid");
	            }
	      
	       }

	}

	private static void rechargeAccount() throws MobileDoesNotExist {
		// TODO Auto-generated method stub
		System.out.println("Enter mobile number to recharge");
		String mno=sc.nextLine();
		while(!(Pattern.matches("((0/91)?[7-9][0-9]{9})",mno)))
		{
			System.out.println("Enter valid mobile no");
			mno=sc.nextLine();
		}
		if(acs.getAccountDetails(mno)!=null)
		{
			System.out.println("Enter amount");
			double amt=sc.nextDouble();
			while(!(amt>0))
			{
				System.out.println("Enter valid amount");
				amt=sc.nextDouble();
			}
				sc.nextLine();
				acs.rechargeAccount(mno, amt);
				System.out.println("Recharged Successfully");
				
				System.out.println("Hello, "+acs.getAccountDetails(mno).getCustomerName()+" now your Account Balance is "+acs.getAccountDetails(mno).getAccountBalance());;
				
			
		}
		
		else
		{
			System.err.println("Mobile no does not Exist");
		}
	}

	private static void balanceEnquirey() throws MobileDoesNotExist {
		// TODO Auto-generated method stub
		System.out.println("Enter Mobile Number");
        String mno=sc.nextLine();
        if(acs.getAccountDetails(mno)!=null)
        {
        	System.out.println("your Account Balance is:"+acs.getAccountDetails(mno).getAccountBalance());
        }
        else
        {
        	System.err.println("Mobile no does not exist");
        }
	}

}
