package com.cq.mra.junit;

import org.junit.Before;
import org.junit.Test;

import com.cq.mra.exception.MobileDoesNotExist;
import com.cq.mra.service.AccountService;
import com.cq.mra.service.AccountServiceImpl;

public class JunitTestCase {
AccountService acs;
	@Before
	public void setUp() throws Exception {
		acs=new AccountServiceImpl();
		
	}

	@Test(expected=com.cq.mra.exception.MobileDoesNotExist.class)
	public void test() throws MobileDoesNotExist {
		acs.getAccountDetails("8192951550");
	}
	@Test
	public void rechargedSuccessfull()
	{
		acs.rechargeAccount("7599407259", 2000);
	}

}
